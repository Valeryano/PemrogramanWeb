function calculate(){
    var n1=document.getElementById("num1").value;
    var n2=document.getElementById("num1").value;

    var result= parseFloat(n1)+parseFloat(n2);

    if(!isNaN(result))
    {
        document.getElementById("answer").innerHTML=alert("Hasilnya adalah: "+result)
    }
}