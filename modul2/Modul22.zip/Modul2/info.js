var nama= document.forms['form']['nama'];
var email= document.forms['form']['email'];
var alamat= document.form['from']['alamat'];


function validated() {
    if(nama.value.length == 0){
        alert("Data harus Terisi");
    }else if(email.value.length == 0){
        alert("Data harus Terisi");
    }else if(alamat.value.length == 0){
        alert("Data harus Terisi");
    }else{
        alert("data tersimpan");
    }
}


